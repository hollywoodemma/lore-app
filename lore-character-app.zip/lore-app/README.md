# LORE — Living Stories

A private, installable iPhone-friendly AI character chat Progressive Web App. Modern chat interface, custom characters, story choices, durable chats, and AI-selected memories. No image generation.

## What's built

- React mobile-first PWA with Home Screen icon, offline shell fallback, character gallery, creator, chat, journal, retry, and optional story choices.
- Cloudflare Worker API with private password login, HttpOnly sessions, D1 storage, and an OpenAI-compatible remote AI endpoint.
- AI model and provider are configurable. Character personalities, recent chat history, and stored memories feed each reply.

## Deploy (Cloudflare account required)

1. Install Node.js 20+ on a computer for deployment. Run `npm install` from this directory.
2. Log in with `npx wrangler login`.
3. Create your database: `npx wrangler d1 create lore-db`.
4. Copy the returned `database_id` into `worker/wrangler.toml`.
5. Apply schema: `npx wrangler d1 execute lore-db --remote --file=worker/schema.sql --config worker/wrangler.toml`.
6. Build the frontend: `npm run build`.
7. Set your AI provider secret: `npx wrangler secret put AI_API_KEY --config worker/wrangler.toml`. Paste your API key when prompted.
8. Edit `AI_MODEL` and `AI_BASE_URL` in `worker/wrangler.toml` to match an available provider/model. The sample OpenRouter free model identifier is **illustrative** and may change or be unavailable; check the provider's current model catalog before deployment. A free provider tier is rate-limited, not unlimited.
9. Deploy: `npx wrangler deploy --config worker/wrangler.toml`.
10. Open the resulting `https://...workers.dev` URL on your iPhone in Safari. Create your private password on first visit. Tap Share → Add to Home Screen.

**Note:** This is a working beta starter, not a production-audited application. It has no password recovery, login throttling, model streaming, push notifications, background proactive messages, chat export, or character editing yet. The "living" behaviors currently occur within active conversations; characters do not message you while the app is closed. Do not expose the deployment URL publicly without adding login rate limits and more robust authentication. A first-run setup race is possible if two people access a fresh deployment at once; keep the initial URL private. PWA installation requires HTTPS (Cloudflare supplies it).

## AI providers

The Worker sends `/chat/completions` requests with an API key and a model identifier. For OpenRouter use `https://openrouter.ai/api/v1`; for other OpenAI-compatible providers, change the base URL and model. Some models don't reliably return structured JSON; the app falls back to plain text, but then won't display choice cards or create memories. Free hosted AI services can have usage limits, moderation, outages, and changing model availability. Never put an API key in frontend files.

## Data/privacy

Your password is PBKDF2-hashed with a unique salt, sessions use secure HttpOnly cookies, and character/chat data is stored in your Cloudflare D1 database. AI requests necessarily send relevant character descriptions, recent messages, and memories to your selected provider. Check its data policies. Deleting a character removes its messages and memories. If you forget the password, there is no self-service recovery in this version.

## Local frontend preview

`npm install && npm run dev` previews the interface, but chat/login require the deployed Worker API. For a complete local Worker environment use Wrangler's local development and initialize a local D1 database.
